export const environment = {
  production: false,
  apiUrl: '/carmar-backend/api'
};
