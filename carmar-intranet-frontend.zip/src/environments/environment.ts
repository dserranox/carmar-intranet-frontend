export const environment = {
  production: true,
  apiUrl: '/carmar-backend/api'
};
