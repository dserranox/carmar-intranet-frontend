
export interface OperacionesDTO {
  opeId: number;
  opeNombre: string;
  opeNombreCorto: string;
  opeDescripcion: string | null;
  opeGrupo: string | null;
  opeOrden: number;
}
